import React from 'react'

const ParentsInfo = () => {
  return (
    <div>ParentsInfo</div>
  )
}

export default ParentsInfo
import React from "react";

const InfoManage = () => {
  return <div></div>;
};

export default InfoManage;

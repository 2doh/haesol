import React from "react";

const NoticeClass = () => {
  return <div>NoticeClass</div>;
};

export default NoticeClass;

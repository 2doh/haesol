import React from "react";

const NoticeModify = () => {
  return <div>NoticeModify</div>;
};

export default NoticeModify;

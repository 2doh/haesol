import StudentGradeChart from "./StudentGradeChart";

const GradeChart = () => {
  const tempObj = () => {};

  return (
    <>
      <StudentGradeChart />
    </>
  );
};

export default GradeChart;

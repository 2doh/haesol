import React from "react";

const GradeStatistics = () => {
  return <div>GradeStatistics</div>;
};

export default GradeStatistics;

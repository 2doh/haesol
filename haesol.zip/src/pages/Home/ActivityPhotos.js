import React from "react";

export const ActivityPhotos = () => {
  return <div>ActivityPhotos</div>;
};

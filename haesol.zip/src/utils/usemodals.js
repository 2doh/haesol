/** 모달 타입 */
export const MODAL_TYPES = {
  //   LoginModal: "LoginModal",
  BasicModal: "BasicModal",
  ArrValueModal: "ArrValueModal",
  PasswordChangeModal: "PasswordChangeModal",
  TelAcceptModal: "TelAcceptModal",
};
